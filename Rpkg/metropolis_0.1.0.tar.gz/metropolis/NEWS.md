# metropolis v0.1.0
## Major changes
- First release on CRAN

## Bug fixes
- N/A